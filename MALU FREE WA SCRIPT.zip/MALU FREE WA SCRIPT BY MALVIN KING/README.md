

  <h2 style="color:#00ffea;">⚙️ Features</h2>
  <ul style="color: #eeeeee; font-size: 16px; text-align: left; max-width: 600px;">
    <li>✅ Auto Status React</li>
    <li>📥 Media Downloader (YT, FB, IG)</li>
    <li>🤖 AI Chat Integration</li>
    <li>📊 Group Tools & Admin Commands</li>
    <li>🚀 Auto View Boosting Contact List</li>
  </ul>

  <hr style="margin: 40px 0; border: 1px dashed #00ffea;" />

  <p style="font-size: 14px; color:#888888;">Made with 💙 by <strong>Malvin King</strong> | 🇿🇼  Zimbabwe</p>

</div>
